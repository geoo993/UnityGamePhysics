﻿using UnityEngine;
using System.Collections;

public class ChainScript : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

		if (Input.GetMouseButtonDown (0)) {
			GetComponent<Rigidbody> ().AddForce (new Vector3 (10, 0, 0), ForceMode.Impulse);
		}
	
	}
}
