﻿using UnityEngine;
using System.Collections;

public class BallScript : MonoBehaviour {

	public float SPEEDX = -1000;

	public float torqueAmount = 100;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

		if (Input.GetMouseButtonDown (0)) {
			GetComponent<Rigidbody> ().AddForce (new Vector3 (SPEEDX, 0, 0) , ForceMode.Force );
			GetComponent<Rigidbody> ().AddTorque (new Vector3 (torqueAmount, torqueAmount, 0), ForceMode.Impulse);
		}
	}


	void OnCollisionEnter(Collision col){
		if (col.gameObject.tag == "Ball") {
			//Debug.Log (" We collided with another ball ! ");
			//GetComponent<Rigidbody>().AddForce(Vector3.up * 20, ForceMode.Impulse);

		}
	}

	void OnTriggerEnter(Collider collider) {
		if (collider.gameObject.tag == "Enemy") {
			GetComponent<Rigidbody> ().AddForce (Vector3.up * 2000, ForceMode.Impulse);
		}
	}

}
