﻿using UnityEngine;
using System.Collections;

public class CarStopScript : MonoBehaviour {

	bool carStopped = false;
	public float lengthOfRay = 15;
	// Use this for initialization
	void Start () {
		carStopped = false;

	}
	
	// Update is called once per frame
	void Update () {
		RaycastHit hit;
		Vector3 direction = new Vector3 (0, 0, -1);
		Ray RayInFrontOfCar = new Ray (transform.position, direction);
		if (carStopped == false) {
			if (Physics.Raycast (RayInFrontOfCar, out hit, lengthOfRay)) {
				carStopped = true;
				BroadcastMessage ("stopNow");
			}
		}

		//Debug.DrawRay (transform.position, direction * lengthOfRay, Color.blue);
			
	}
}
