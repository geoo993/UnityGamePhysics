﻿using UnityEngine;
using System.Collections;

public class SpawnCharacters : MonoBehaviour {

	string character1 = "DuckPrefab";
	string character2 = "chickenPrefab";
	string character3 = "ChickenBrownPrefab";

	float timeToWait;
	float timeWaiting;
	int randomObjectIndex = 0;

	// Use this for initialization
	void Start () {
		timeWaiting = 0;
		timeToWait = Random.Range (0.3f, 1.0f);
		

	}
	
	// Update is called once per frame
	void Update () {
	
		if (timeWaiting > timeToWait) {
			randomObjectIndex = Random.Range (0, 3);
			string name = character1;
			switch (randomObjectIndex) {
			case 1:
				name = character2;
				break;

			case 2:
				name = character3;
				break;
			}

			GameObject go = Instantiate (Resources.Load (name)) as GameObject;
			go.transform.position = this.transform.position;
			timeWaiting = 0;
			timeToWait = Random.Range (0.3f, 1.0f);
		
		} else {
			timeWaiting += Time.deltaTime;
		}

	}
}
