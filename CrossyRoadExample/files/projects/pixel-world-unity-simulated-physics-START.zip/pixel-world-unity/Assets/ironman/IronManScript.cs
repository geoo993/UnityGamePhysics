﻿using UnityEngine;
using System.Collections;

public class IronManScript : MonoBehaviour {

	public GameObject EnergyBeam;
	private Animator animator;
	float vSpeed;
	// Use this for initialization
	void Start () {
		animator = this.GetComponent<Animator> (); 
	
	}
	
	// Update is called once per frame
	void Update () {
		vSpeed = Input.GetAxis ("Vertical");
		animator.SetFloat("VSpeed", vSpeed );

		if (Input.GetButtonDown ("Jump")) {
			animator.SetBool("Jumping", true);
			Invoke("StopJump", 0.1f);
		}

		if (Input.GetButtonDown ("Fire2")) {
			animator.SetBool("turning", true);
			Invoke ("StopTurning", 0.1f);
		}


		if (Input.GetButtonDown ("Fire1")) {
			animator.SetBool("BlastingEnergy", true);
			Invoke ("StopBlastingEnergy", 0.1f);
		}
	
	}

	void StopJump()
	{
		animator.SetBool ("Jumping", false);
	}

	void StopTurning(){
		animator.SetBool ("turning", false);
	}

	void StopBlastingEnergy(){
		animator.SetBool ("BlastingEnergy", false);
	}


	void ShootBeam(){
		EnergyBeam.BroadcastMessage ("Shoot");
	}



}



















