﻿using UnityEngine;
using System.Collections;
//using ChartboostSDK;

public class ShowChartboostAds : MonoBehaviour {

	// Use this for initialization
	void Start () {
		//Chartboost.cacheInterstitial(CBLocation.HomeScreen);

	}
	
	// Update is called once per frame
	void Update () {
		if (Input.touchCount > 0)
		{
			//Chartboost.showInterstitial(CBLocation.HomeScreen);
		}
		
	}
	
}
