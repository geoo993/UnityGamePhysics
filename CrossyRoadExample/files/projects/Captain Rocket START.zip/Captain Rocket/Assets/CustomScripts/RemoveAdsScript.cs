﻿using UnityEngine;
using System.Collections;
using Soomla.Store;
using System.Collections.Generic;
using System;

public class RemoveAdsScript : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}


	void RemoveAds()
	{

	}
}
